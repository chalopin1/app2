module.exports = {

    database: {
        connectionLimit: 10,
        host: 'localhost',
        user: 'chalopin',
        password: 'Pequita1',
        database: 'i6909016_wp1'
    }

};
